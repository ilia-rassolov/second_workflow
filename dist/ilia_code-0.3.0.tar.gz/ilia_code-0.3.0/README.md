Это мой учебный репозиторий для отработки Git Action


[![.github/workflows/setup.yml](https://github.com/ilia-rassolov/second_workflow/actions/workflows/setup.yml/badge.svg)](https://github.com/ilia-rassolov/second_workflow/actions/workflows/setup.yml)



