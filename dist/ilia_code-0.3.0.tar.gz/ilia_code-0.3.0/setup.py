# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello', 'hello.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['hello = hello.scripts.hello_world:main']}

setup_kwargs = {
    'name': 'ilia-code',
    'version': '0.3.0',
    'description': '',
    'long_description': '',
    'author': 'Ilia Rassolov',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
