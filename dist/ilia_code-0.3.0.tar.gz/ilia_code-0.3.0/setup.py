# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello', 'hello.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['hello = hello.scripts.hello_world:main']}

setup_kwargs = {
    'name': 'ilia-code',
    'version': '0.3.0',
    'description': '',
    'long_description': 'Это мой учебный репозиторий для отработки Git Action\n\n\n[![.github/workflows/setup.yml](https://github.com/ilia-rassolov/second_workflow/actions/workflows/setup.yml/badge.svg)](https://github.com/ilia-rassolov/second_workflow/actions/workflows/setup.yml)\n\n\n\n',
    'author': 'Ilia Rassolov',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
